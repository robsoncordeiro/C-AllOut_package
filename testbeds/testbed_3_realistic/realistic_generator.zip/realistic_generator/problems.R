
source("check-packages.R")
source("R/data-handling.R")
source("R/dists.R")
source("R/problems-funs.R")
source("helper.R")


# Add problems ------------------------------------------------------------

meta_data <- data.frame(name=character(),
                        instances=integer(),
                        outliers=integer(),
                        outliers_perc=numeric(),
                        attributes=integer(),
                        inst_per_attr=numeric())
files <- list.files(path="datasets")
files <- files[grep(pattern=".arff", x=files)]
for(cur_file in files) {
  dataset <- importData("datasets", cur_file)
  data_name <- getDataName(file=cur_file)
  
  # Lymphography does not have numeric attributes with enough distinct values
  # InternetAds does not have numeric values with 'outliers'
  # Arrhythmia really seems to be difficult in terms of differentiating between continous and discrete.
  # KDDCup99 the same
  if(data_name %in% c("Lymphography", "InternetAds")) {
    next()
  }
  
  ### CAUTION ----------------
  # 1) Only numeric attributes (and 'outlier')
  dataset <- keepNumeric(dataset)
  # 2) Only attributes with more than 10 distinct values
  dataset <- removeInfreq(dataset, min_n_val = 10)
  # 3) Remove duplicates of all rows (to keep consistency if not jittered)
  dataset <- removeDuplicates(dataset)
  # # 4) Normalize attributes to [0,1] (done in the problem functions)
  dataset <- normalizeDataset(dataset)
  
  new_meta <- data.frame(name=data_name,
                         instances=nrow(dataset),
                         outliers=sum(dataset$outlier=="yes"),
                         outliers_perc=sum(dataset$outlier=="yes")/nrow(dataset),
                         attributes=ncol(dataset)-1,
                         inst_per_attr=nrow(dataset)/(ncol(dataset)-1))
  meta_data <- rbind(meta_data, new_meta)  
  cat(paste0("######## ", data_name, " (", which(cur_file==files), " of ", length(files), ")", " ######## \n"))
  # addProblem(name = paste0("Real_", data_name), data = dataset, fun = real, seed = 312)
  # addProblem(name = paste0("SynthRegular_", data_name), data = dataset, fun = synthRegular, seed = 312)
  addProblem(name = paste0("SynthOutlier_", data_name), data = dataset, fun = synthOutlier, seed = 312)
  # addProblem(name = paste0("Synth_", data_name), data = dataset, fun = synth, seed = 312)
  cat("\n")
}
write.csv(meta_data, file="datasets/meta-data.csv", row.names = FALSE)

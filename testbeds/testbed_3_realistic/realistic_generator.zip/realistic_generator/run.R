source("initalize-batchtools.R")

ids_not_done <- findNotDone()
removeExperiments(ids_not_done)

source("design.R")

reg <- loadRegistry(file.dir = "registry", writeable = TRUE)
reg$packages <- cran
reg$source <- c("helper.R", paste0("R/", list.files("R")))

reg$cluster.functions = makeClusterFunctionsSocket()

ids_not_done <- findNotDone()
submitJobs(ids=ids_not_done)
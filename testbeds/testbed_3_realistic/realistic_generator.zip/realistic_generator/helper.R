
# Problems ----------------------------------------------------------------

# Seperate regulars and outliers, sampel them down if they are to much and compute xi if missing
prepareData <- function(data, max_reg, max_out) {
  
  # Seperate outliers and regulars
  real_regulars <- data %>%
    filter(outlier=="no") %>%
    select(-outlier)
  real_outliers <- data %>%
    filter(outlier=="yes") %>%
    select(-outlier)
  
  # Sample down if outliers or regulars are to much
  if(nrow(real_regulars) > max_reg) {
    warning("Number of regular instances greater than max_reg: ",
            nrow(real_regulars)," > ", max_reg, ". Sampling down.")
    real_regulars <- real_regulars %>%
      sample_n(size = max_reg)
  }
  if(nrow(real_outliers) > max_out) {
    warning("Number of outliers greater than max_out: ",
            nrow(real_outliers)," > ", max_out, ". Sampling down.")
    real_outliers <- real_outliers %>%
      sample_n(size = max_out)
  }
  
  return(list(real_regulars=real_regulars,
              real_outliers=real_outliers))
  
}

sampleOutlier <- function(real_outliers, xi, n_reg) {
  
  # Do not downsample if xi is NA
  if(is.na(xi)) {
    return(real_outliers)
  }
  
  n_out <- nrow(real_outliers)
  new_n_out <- ceiling((n_reg*xi)/(1-xi))
  
  # Use all outliers if xi is to high
  if(new_n_out > n_out) {
      warning("Not enugh outlier for given xi of ",
              round(xi, 4),
              ". Using all real outliers. Hence, xi is ",
              round(n_out/(n_out + n_reg), 4),
              ".")
      return(real_outliers)
  }
  
  sample_real_outliers <- real_outliers %>%
    sample_n(new_n_out)
  
  return(real_outliers %>% sample_n(new_n_out))

}

switchNSynth <- function(n_synth_reg, n_real_reg, n_d) {
  switch(n_synth_reg,
         real_n = { # Number of synthetic instances equals real regular instances
           n_synth_reg <- n_real_reg
         },
         increase_with_d = {
           n_synth_reg <- 100 * n_d
         },
         {
           n_synth_reg <- as.numeric(n_synth_reg)
         }
  )
  return(n_synth_reg)
}

#' Sometimes kded1d from kde1d apckage does not work properly (i.e. gives only NaN values)
#' @example 
#' x <- c(0.4855497, 0.4870833, 0.4872106, 0.4871475, 0.4872785, 0.4867576, 0.4871979, 0.4870697, 0.4871810, 0.5843775)
#' kde1d::kde1d(x)$values 
my_kde1d <- function(x) {
  kde1d_fit <- kde1d::kde1d(x=x)
  if(!all(is.finite(kde1d_fit$values))) {
    warning("kde1d::kde1d produces NaN values. Switching to deg=0 instead of default deg=2.")
    kde1d_fit <- kde1d::kde1d(x=x, deg = 0)
  } 
  return(kde1d_fit)
}

jitterAttr <- function(attribute, dist="usb") {
  
  unique_vals <-  unique(attribute)
  
  if(length(unique_vals) < length(attribute)) {
    
    
    if(length(unique_vals) == 1) {
      minimal_difference <- 1 # use full attribute range (might get negative though)
    } else {
      minimal_difference <- min(dist(unique_vals))
    }
    
    dup_idx <- which(duplicated(attribute)) 
    
    switch (dist,
            unif = {
              noise <- runif(n = length(dup_idx), min = -minimal_difference/2, max = minimal_difference/2)
            },
            gauss = {
              # Nosie is such that ~95 % confidence interval of gauss is within +- minimal_difference/2
              noise <- rnorm(n = length(dup_idx), mean = 0, sd = (minimal_difference/2)/qnorm(0.95))
            },
            usb = {
              # Nosie is such that uniform part is within +- minimal_difference/2
              noise <- (cctools::rusb(n = length(dup_idx), theta = 0.8, nu = 5)/0.5) * minimal_difference/2
            },
            {
              stop("\"dist\" ", dist, " not implemented.")
            }
    )
    
    attribute[dup_idx] <-  attribute[dup_idx] + noise
    
  }
  
  return(attribute)
  
} # END fun jitterAttr

# importData <- function(inputPath, fileName){
#   if(grepl(".csv", fileName)){
#     dataset_labeled <- fread(paste0(inputPath, "/", fileName))
#   }else{
#     dataset_labeled <- as.data.table(read.arff(paste0(inputPath,"/", fileName)))
#   }
#   if("id" %in% names(dataset_labeled)){
#     dataset_labeled <- dataset_labeled[,!"id", with=F]  
#   }
#   if("outlier" %in% names(dataset_labeled)) {
#     names(dataset_labeled)[which(names(dataset_labeled)=="outlier")] <- "class"
#   }
#   if("yes" %in% levels(dataset_labeled$class)){
#     dataset_labeled$class <- as.numeric(dataset_labeled$class == "yes")
#   }else{
#     if(is.factor(dataset_labeled$class)){
#       dataset_labeled$class <- as.numeric(levels(dataset_labeled$class))[dataset_labeled$class]
#     }
#     dataset_labeled[,class:=ifelse(class>0, 1, 0),]
#   } 
#   return(dataset_labeled)
# }
# 
# normaliseData <- function(dataset) {
#   return(as.data.table(apply(dataset, 2, scales::rescale, to = c(0,1))))
# }
# 
# determineDiscreteAttr <- function(dataset, min_n_vals=20) {
#   count_distinct <- apply(dataset, 2, function(x) length(unique(x)))
#   bol_discrete <- count_distinct < min_n_vals
#   if("class" %in% names(dataset)) {
#     bol_discrete[names(dataset) == "class"]  <- FALSE
#   }
#   return(list(discrete=names(dataset)[bol_discrete],
#               continuous=names(dataset)[!bol_discrete]))
# }

# getNArts <- function(n, xi) {
#   return(ceiling(xi*n/(1-xi))) # use of ceiling such that at least 1
# }
#
# addNoise <- function(dataset, bw_val, type="gauss") {
#   switch (type,
#           gauss = {
#             noise <- rnorm(n = nrow(dataset)*ncol(dataset), sd = bw_val)
#           },{
#             stop("Type ", type, " not supported.") 
#           }
#   ) # END switch type
#   noise <- matrix(noise, nrow = nrow(dataset), ncol = ncol(dataset))
#   return(dataset + noise)
# }


# Algorithms --------------------------------------------------------------

getFamily <- function(treeCopulas) {
  unlist(lapply(treeCopulas, function(x) x$family))
}

reduceFitList <- function(fit, dist_type) {
  if(is.null(dist_type)) {
    return(NULL)
  } else {
    switch (dist_type,
            vine = {
              return(list(pair_copulas=fit$copula$pair_copulas,
                          structure=fit$copula$structure))
            },
            gauss = {
              return(fit[c("modelName", "n", "d", "G", "parameters")])
            },
            unif = {
              return(fit)
            },
            ranger = {
              return(fit$results)
            },
            {
              stop("dist_type ", dist_type, "not supported.")
            }
    ) 
  }
}

# Get Result --------------------------------------------------------------

outlabelToBinary <- function(label_vec) {
  if(!any(c(0,1) %in% label_vec)) {
    binary_label <- rep(0, length(label_vec))
    binary_label[label_vec == "yes"] <- 1
    return(binary_label)
  } else {
    return(label_vec)
  }
}

getDirection <- function(method_name) {
  # levels: c(0,1) where 0 is regular and 1 is outlier
  if(method_name %in% c("lof", "glosh", "iso", "ideal")) {
    return("<") # outlier (positive, 1) have higher values
  } else {
    return(">") # regular (negative, 0) have higher values
  }
}

sanitizePrediction <- function(pred) {
  idx_finite <- which(is.finite(pred))
  idx_pos_inf <- which(is.infinite(pred) & pred > 0)
  if(length(idx_pos_inf) > 0) {
    pred[idx_pos_inf] <- max(pred[idx_finite]) + 1
    warning("Prediction contains ", length(idx_pos_inf), " values with \"Inf\" (~",
            round(length(idx_pos_inf)/length(pred), 2)*100, 
            "%). Replacing \"Inf\" with maximal finite prediction + 1.")
  }
  idx_neg_inf <- which(is.infinite(pred) & pred < 0)
  if(length(idx_neg_inf) > 0) {
    pred[idx_neg_inf] <- min(pred[idx_finite]) - 1
    warning("Prediction contains ", length(idx_neg_inf), " value(s) with \"-Inf\" (~",
            round(length(idx_neg_inf)/length(pred), 2)*100, 
            "%). Replacing \"-Inf\" with minimal finite prediction - 1.")
  }
  idx_nan <- which(is.nan(pred))
  if(length(idx_nan) > 0) {
    pred[idx_nan] <- mean(pred[idx_finite])
    warning("Prediction contains ", length(idx_nan), " value(s) with \"NaN\" (~",
            round(length(idx_nan)/length(pred), 2)*100, 
            "%). Replacing \"NaN\" with average finite prediction.")
  }
  return(pred)
}

unifyDirection <- function(predictor, direction) {
  if(direction == ">") { # regular (negative, 0) have higher values
    return(-predictor)
  } else {
    return(predictor)
  }
}

aucFun <- function(response, predictor, levels, direction, curve) {
  
  predictor <- sanitizePrediction(predictor)
  
  switch(curve,
         ROC = {
           auc <- pROC::auc(response,
                            predictor,
                            levels=levels,
                            direction=direction)
         },
         PR = {
           predictor <- unifyDirection(predictor, direction)
           auc <- PRROC::pr.curve(scores.class0 = predictor,
                                  weights.class0 = response)$auc.integral
         },
         {
           stop("Curve ", curve, " not supported for AUC.")
         })
  return(as.numeric(auc))
}

# curve = "ROC" or "PR"
getAUC <- function(response, score_list, curve="ROC") {
  
  auc_list <- score_list
  for(apr_idx in 1:length(score_list)) {
    auc_list[[apr_idx]] <- aucFun(response=response,
                                  predictor=score_list[[apr_idx]],
                                  levels=c(0, 1),
                                  direction=getDirection(names(score_list)[apr_idx]),
                                  curve=curve)
  }
  
  names(auc_list) <- paste0(names(auc_list), "_", curve)
  
  return(auc_list)
  
  # return(list(auc=as.numeric(auc), # AUC when using prediction of the method
  #             auc_ideal=as.numeric(auc_ideal), # AUC when using the two distributions that generated the data
  #             auc_low_dens=as.numeric(auc_low_dens))) # AUC when using real density as scoring
}

getCor <- function(score_list, cor_method="kendall") {
  
  if(length(score_list) == 1) {
    return(NULL)
  }
  
  # Make direction similar
  for(apr_idx in 1:length(score_list)) {
    score_list[[apr_idx]] <- unifyDirection(predictor=score_list[[apr_idx]],
                                            direction=getDirection(names(score_list)[apr_idx]))
  }
  
  apr_combs <- combn(x=names(score_list), m=2)
  cor_res <- NULL
  cor_res_names <- NULL
  for(comb_idx in 1:ncol(apr_combs)) {
    apr_x_name <- apr_combs[1,comb_idx]
    apr_y_name <- apr_combs[2,comb_idx]
    cor_res <- c(cor_res, cor(x=score_list[[apr_x_name]], 
                              y=score_list[[apr_y_name]],
                              method=cor_method))
    cor_res_names <- c(cor_res_names, paste0(apr_x_name, "_", apr_y_name))
  }
  names(cor_res) <- cor_res_names
  
  return(cor_res)
  
}

getQual <- function(result_list) {
  
  ## Prediction of detecetion approach
  score_list <- list(method=result_list$method_pred)
  names(score_list)  <- result_list$method_name
  
  if(!is.null(result_list$dens_reg)) {
    ## (1 - xi) * dens_reg
    pred_low_dens_reg <- log( ((1 - result_list$xi) * result_list$dens_reg) )
    score_list <- c(score_list, list(low_dens_reg=pred_low_dens_reg))
    if(!is.null(result_list$dens_out)) {
      ## xi * dens_out / (1 - xi) * dens_reg
      pred_ideal <- log( (result_list$xi * result_list$dens_out) / ((1 - result_list$xi) * result_list$dens_reg) )
      score_list <- c(score_list, list(ideal=pred_ideal))
      ## xi * dens_out + (1 - xi) * dens_reg
      pred_low_dens_overall <- log( (result_list$xi * result_list$dens_out) + ((1 - result_list$xi) * result_list$dens_reg) )
      score_list <- c(score_list, list(low_dens_overall=pred_low_dens_overall))  
    }
  }
  
  response <- outlabelToBinary(result_list$process_label)
  roc_list <- getAUC(response=response,
                     score_list=score_list,
                     curve="ROC")
  pr_list <- getAUC(response=response,
                    score_list=score_list,
                    curve="PR")
  cor_list <- getCor(score_list=score_list)
  
  qual_res <- c(roc_list, pr_list, cor_list)
  names(qual_res) <- str_replace(names(qual_res), result_list$method_name, "method")
  
  return(qual_res)
  
}

reduceQualToTable <- function(result_list, algorithm="DetectOutliers") {
  switch (algorithm,
          DetectOutliers = {
            idx_fits <- which(names(result_list) == "fitRegular" | names(result_list) == "fitOutlier")
            return(result_list[-idx_fits])         
          },
          ClassifyOutliers = {
            idx_fits <- which(names(result_list) == "fitClass")
            return(result_list[-idx_fits])         
          },
          {
            stop("Algorithm ", algorithm, " not supported.")
          }
  )
}


getClassQual <- function(result_list) {
 
  pred <- factor(result_list$method_pred)
  label <- factor(result_list$process_label)
  
  return(caret::postResample(pred=pred, obs=label))
   
}

# Others ------------------------------------------------------------------

writeDistTypeOut <- function(dist_type) {
  dist_type <- ifelse(dist_type=="real", "Real", dist_type)
  dist_type <- ifelse(dist_type=="gauss", "Gaussian", dist_type)
  dist_type <- ifelse(dist_type=="vine", "Vine", dist_type)
  dist_type <- ifelse(dist_type=="unif", "Uniform", dist_type)
  return(dist_type)
}


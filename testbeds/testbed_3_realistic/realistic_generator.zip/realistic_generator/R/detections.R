

# KDE ---------------------------------------------------------------------

kde <- function(dataset, method_par) {
  
  bws_unsup <- np::npudensbw(bwmethod = 'normal-reference',
                             dat = dataset,
                             bandwidth.compute = TRUE)
  
  pred_unsup <-  np::npudens(bws_unsup)$dens
  
  return(list(unsup_scores=pred_unsup,
              method_fit=list(bw_unsup=bws_unsup)))
}


# Weighted KNN ------------------------------------------------------------

# vol_hypersphere <- function(r = 1, d = 1) {
#   nom   = pi ^ (d/2)
#   denom = gamma(d/2 + 1)
#   unit_vol = nom / denom
#   return ( unit_vol * (r ^ d) )
# }
# 
# uniform_v <- function(data, query, k = 10, unsupervised=TRUE) {
#   n = nrow(data)
#   d = ncol(data)
#   k = round(k)
#   vol <- vol_hypersphere(r=1, d = d)
#   
#   if(unsupervised) {
#     radius_per_query <- apply(FNN::knn.dist(data, k = k)^d, 1, sum)
#   } else {
#     radius_per_query <- apply(FNN::knnx.dist(data, query, k = k)^d, 1, sum)
#   }
#   density_per_query = ((k*(1+k)) / (2*n*vol)) * (1 / radius_per_query)
#   
#   return (density_per_query)
# }

wknn <- function(dataset, method_par) {

  method_par <- min(nrow(dataset) - 1, method_par) ### CAUTION reduce k if data is small.
  
  pred_unsup <- apply(FNN::knn.dist(data=dataset, k = method_par)^d, 1, sum)
  
  return(list(unsup_scores=pred_unsup))
  
}



# LOF ---------------------------------------------------------------------

lof <- function(dataset, method_par) {
  
  method_par <- min(nrow(dataset) - 1, method_par) ### CAUTION reduce k if data is small.
  
  lof_scores <- dbscan::lof(x = dataset, k = method_par)
  
  return(list(unsup_scores=lof_scores))
}



# Isolation Forrest -------------------------------------------------------

iso <- function(dataset, method_par) {
  # devtools::install_github("Zelazny7/isofor")
  
  # Values from puplication (bit 'phi' might be smaller)
  phi = 256
  nt = 100
  phi <- min(0.7 * nrow(dataset), phi) ### CAUTION reduce phi if data is small.
  
  unsupervised_iso <- isofor::iForest(X=dataset,
                                      nt = nt, 
                                      phi = phi)
  pred_unsup <- predict(object=unsupervised_iso, 
                        newdata=dataset)
  
  return(list(unsup_scores=pred_unsup,
              method_fit=list(unsupervised_iso=unsupervised_iso)))
}



# Wang --------------------------------------------------------------------

# source("R/positive-shift.R")
# fitWang <- function(dataset) {
#   
#   # set up grid
#   gammas <- c(10^{-4}, 10^{-3}, 10^{-2}, 10^{-1}, 10, 10^{1}, 10^{2}, 10^{3},10^{4}) # from Yu, Jaehong, and Seokho Kang. 2018. “Clustering-Based Proxy Measure for Optimizing One-Class Classifiers.” Pattern Recognition Letters, November. https://doi.org/10.1016/j.patrec.2018.11.017.
#   nus <- c(0.01, 0.05, 0.1)
#   
#   err = Inf
#   best_conf = NULL
#   best_fit = NULL
#   neg_res = artouts::negShift(dataset=dataset)
#   neg_res_values = neg_res$placed
#   pos_shifts = posShift(dataset, neg_res$intermediates$res_list_epd)
#   for(gamma in gammas) {
#     for(nu in nus) {
#       svm_fit <- e1071:::svm(dataset, y = NULL,type='one-classification',
#                              nu=nu, gamma=gamma)
#       pred_neg <- e1071:::predict.svm(object = svm_fit,
#                                       newdata = neg_res_values)
#       avg_err_neg = sum(pred_neg)/length(pred_neg)
#       pred_pos <- e1071:::predict.svm(object = svm_fit,
#                                       newdata = pos_shifts)
#       avg_err_pos = (length(pred_pos)-sum(pred_pos))/length(pred_pos)
#       this_err = 0.5*avg_err_neg + 0.5*avg_err_pos
#       if (this_err < err) {
#         err = this_err
#         best_fit = svm_fit
#         best_conf = c(gamma, nu)
#       }
#     }
#   }
#   return(best_fit)
# }
# predictWang <- function(newdata, ocsvm_fit) {
#   pred <- e1071:::predict.svm(object = ocsvm_fit, 
#                               newdata = newdata,
#                               decision.values=TRUE)
#   return(attr(pred, "decision.values")[,1])
# }
# wang <- function(dataset, method_par) {
#   
#   unsupervised_wang <- fitWang(dataset=dataset)
#   pred_unsup <- predictWang(newdata=dataset,
#                             ocsvm_fit=unsupervised_wang)
#   
#   return(list(unsup_scores=pred_unsup,
#               method_fit=list(unsupervised_wang=unsupervised_wang)))
# }
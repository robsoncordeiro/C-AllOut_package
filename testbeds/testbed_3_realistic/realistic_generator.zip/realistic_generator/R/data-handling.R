
importData <- function(inputPath, fileName){
  dataset <- foreign::read.arff(paste0(inputPath,"/", fileName))
  dataset <- dataset[,- c(which(names(dataset) == "id"))]
  return(dataset)
}

getDataName <- function(file) {
  name_parts <- substr(file, start = 1, stop = nchar(file) - 5)
  name_parts <- strsplit(name_parts, split = "_")[[1]]
  return(name_parts[1])
}

keepNumeric <- function(dataset) {
  numeric_dataset <- dataset %>%
    select(which(sapply(.,class) == "numeric"), "outlier")
  return(numeric_dataset)
}

removeInfreq <- function(dataset, min_n_val) {
  distinct_vals <- dataset %>%
    select(-"outlier") %>%
    summarise_all(function(x) length(unique(x))) %>%
    gather("attribute", "n_vals") %>%
    mutate(perc_vals = n_vals/nrow(dataset)*100)
  distinct_dataset <- dataset %>%
    select(distinct_vals %>% filter(n_vals >= min_n_val) %>% pull(attribute), "outlier")
  if(ncol(distinct_dataset) == 1) {
    stop("No attributes remaining after removing infrequent values.")
  }
  return(distinct_dataset)
}

removeDuplicates <- function(dataset) {
  bol_duplicated <- duplicated(dataset[!names(dataset) %in% c("outlier")])
  return(dataset[!bol_duplicated,])
}


normalizeAttr <- function(attribute) {
  attribute <- attribute - min(attribute)
  return(attribute/max(attribute))
} # END fun normalizeAttr
normalizeDataset <- function(dataset) {
  normalized_dataset <- dataset %>%
    mutate_at(which(names(dataset) != "outlier"), normalizeAttr)
  return(normalized_dataset)
}


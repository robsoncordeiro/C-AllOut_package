
epmf <- function (x) {
  x <- sort(x)
  n <- length(x)
  if (n < 1) 
    stop("'x' must have 1 or more non-missing values")
  vals <- unique(x)
  rval <- approxfun(vals, tabulate(match(x, vals))/n, # Removed cumsum from "stats::ecdf" here
                    method = "constant", yleft = 0, yright = 0, f = 0, ties = "ordered") # Changed yright from 1 to 0
  class(rval) <- c("ecdf", "stepfun", class(rval))
  assign("nobs", n, envir = environment(rval))
  attr(rval, "call") <- sys.call()
  rval
}

# U transformation
continuousMarginFun <- function(x) {
  # kde_fit <- kde1d::kde1d(x)
  return(kde1d::kde1d(x))
}
discreteMarginProbFun <- function(x) {
  return(ecdf(x))
}

# Density
discreteMarginDensityFun <- function(x) {
  return(epmf(x))
}


determineDiscreteAttr <- function(dataset, perc=0.2) {
  count_distinct <- apply(dataset, 2, function(x) length(unique(x)))
  perc_distinct <- count_distinct/nrow(dataset)
  bol_discrete <- count_distinct < 10 | perc_distinct < perc
  return(list(discrete=names(dataset)[bol_discrete],
              continuous=names(dataset)[!bol_discrete]))
}

fitMarginsProb <- function(dataset) {
  
  var_names <- determineDiscreteAttr(dataset)
  densFuns <- vector(mode = "list", length=ncol(dataset))
  names(densFuns) <- names(dataset)
  
  for(discrete_name in var_names$discrete) {
    densFuns[[discrete_name]] <- discreteMarginProbFun(dataset %>% pull(discrete_name))
  }
  for(continuous_name in var_names$continuous) {
    densFuns[[continuous_name]] <- continuousMarginFun(dataset %>% pull(continuous_name))
  }
  
  return(list(densFuns=densFuns, var_names=var_names))
}
uTransform <- function(dataset, margins_prob) {
  
  u_data <- dataset
  for(discrete_name in margins_prob$var_names$discrete) {
    u_data <- u_data %>%
      mutate_at(discrete_name, margins_prob$densFuns[[discrete_name]]) 
  }
  for(continuous_name in margins_prob$var_names$continuous) {
    u_data <- u_data %>%
      mutate_at(continuous_name, function(x) kde1d::pkde1d(q=x, obj=margins_prob$densFuns[[continuous_name]]))
  }
  
  return(u_data)
  
}
invUTransform <- function(u_data, margins_prob) {
  
  dataset <- u_data
  for(discrete_name in margins_prob$var_names$discrete) {
    dataset <- dataset %>%
      mutate_at(discrete_name, margins_prob$densFuns[[discrete_name]]) 
  }
  for(continuous_name in margins_prob$var_names$continuous) {
    dataset <- dataset %>%
      mutate_at(continuous_name, function(x) kde1d::qkde1d(p=x, obj=margins_prob$densFuns[[continuous_name]]))
  }
  
  return(u_data)
  
}



#' Formats the real data set for use in the algorithms.
#' 
#' @param data Real data set. (BATCHTOOLS)
#' @param job Batchtools job. (BATCHTOOLS)
#' @param xi Percentage of outliers in generated data. Numeric in [0,1] or 'NA'.
#' If 'NA' all outliers up to max_reg are used.
#' @param max_reg Maximal number of regular instances. If 'Inf' all are used.
#' @param max_out Maximal number of outliers. If 'Inf' all are used.
#' @param perc_train Percentage of data used for training. If 'NA' there is no 
#' train-test split (unsupervised detcetion).
#' 
#' @return A list with the real data.
real <- function(data, job=NULL, # specific to batchtools
                 xi=NA, max_reg=Inf, max_out=Inf, perc_train=NA) {
  
  prep_list <- prepareData(data=data, max_reg=max_reg, max_out=max_out)
  
  n_reg <- nrow(prep_list$real_regulars)
  sample_real_outliers <- sampleOutlier(real_outliers=prep_list$real_outliers,
                                        xi=xi,
                                        n_reg=n_reg)
  n_sample_out <- nrow(sample_real_outliers)
  
  # Create train and test samples (for classification)
  if(!is.na(perc_train)) {
    train_idx_reg <- sample(1:n_reg, perc_train*n_reg)
    train_idx_out <- sample(1:n_sample_out, perc_train*n_sample_out)
    
    train_data <- rbind(prep_list$real_regulars[train_idx_reg,],
                        sample_real_outliers[train_idx_out,]) %>%
      bind_cols(outlier=c(rep("no", length(train_idx_reg)),
                          rep("yes", length(train_idx_out))))
    
    test_list <- list(data=rbind(prep_list$real_regulars[-train_idx_reg,],
                                 sample_real_outliers[-train_idx_out,]),
                      label=c(rep("no", nrow(prep_list$real_regulars[-train_idx_reg,])),
                              rep("yes", nrow(sample_real_outliers[-train_idx_out,]))))
    
    return(list(train=real(data=train_data), # Recursive call to this function (with perc_train=NA and only train split)
                test=test_list))
  }
  
  return(list(data=as.matrix(rbind(prep_list$real_regulars,
                                   sample_real_outliers)),
              label=c(rep("no", n_reg),
                      rep("yes", n_sample_out)),
              xi=xi,
              dist_type_reg=NULL,
              fit_real_out=NULL,
              dist_type_out=NULL,
              fitRegular=NULL,
              fitOutlier=NULL))
  
} # END fun real
# ------------------------------------------------------------------- #



#' Generate a outlier benchmark data set with synthetic regular instances but real outliers.
#' 
#' @param data Real data set. (BATCHTOOLS)
#' @param job Batchtools job. (BATCHTOOLS)
#' @param dist_type_reg Type of distribution that is used for the outliers. Either 'vine',
#' 'gauss' or 'unif'.
#' @param n_synth_reg Number of regular instances to generate. Either an integer > 0,
#' 'real_n' to use the number of instances from the real data or 
#' 'increase_with_d' to increase samples with dimensionality.
#' @param xi Percentage of outliers in generated data. Numeric in [0,1] or 'NA'.
#' If 'NA' all outliers up to max_reg are used.
#' @param max_reg Maximal number of regular instances. If 'Inf' all are used.
#' @param max_out Maximal number of outliers. If 'Inf' all are used.
#' @param perc_train Percentage of data used for training. If 'NA' there is no 
#' train-test split (unsupervised detcetion).
#' 
#' @return A list with the data having real regulars but synthetic outliers.
synthRegular <- function(data, job=NULL, # specific to batchtools
                         dist_type_reg, n_synth_reg,
                         xi=NA, max_reg=Inf, max_out=Inf, perc_train=NA) {
  
  if(!is.na(perc_train)) {
    if(!is.na(xi)) {
      stop("Not supporting xi with synthetic data and train-test split.")
    }
    tt_list <- real(data=data,
                    xi=NA,
                    max_reg=max_reg,
                    max_out=max_out, 
                    perc_train=perc_train)
    tt_list$train <- synthRegular(data=tt_list$train$data %>%
                                    as.data.frame() %>%
                                    bind_cols(outlier=tt_list$train$label),
                                  dist_type_reg=dist_type_reg,
                                  n_synth_reg=n_synth_reg,
                                  xi=xi)
    return(tt_list)
  }
  
  prep_list <- prepareData(data=data, max_reg=max_reg, max_out=max_out) 
  
  n_synth_reg <- switchNSynth(n_synth_reg=n_synth_reg, 
                              n_real_reg=nrow(prep_list$real_regulars), 
                              n_d=ncol(prep_list$real_regulars))
  
  # Fit regulars
  real_regulars <- prep_list$real_regulars %>%
    mutate_all(jitterAttr)
  fitRegular <- do.call(paste0(dist_type_reg, "Fit"), list(dataset=real_regulars))
  
  # Create synthetic samples
  synth_regulars <- do.call(paste0(dist_type_reg, "Sample"),
                            list(fit=fitRegular,
                                 n=n_synth_reg))
  colnames(synth_regulars) <- colnames(prep_list$real_regulars)
  
  # Downsample outliers
  sample_real_outliers <- sampleOutlier(real_outliers=prep_list$real_outliers,
                                        xi=xi,
                                        n_reg=n_synth_reg)
  
  return(list(data=as.matrix(rbind(synth_regulars, sample_real_outliers)),
              label=c(rep("no", n_synth_reg),
                      rep("yes", nrow(sample_real_outliers))),
              xi=xi,
              dist_type_reg=dist_type_reg,
              fit_real_out=NULL,
              dist_type_out=NULL,
              fitRegular=fitRegular,
              fitOutlier=NULL))
  
} # END fun synthRegular
# ------------------------------------------------------------------- #


#' Generate a outlier benchmark data set with synthetic outliers bur real regular instances.
#' 
#' @param data Real data set. (BATCHTOOLS)
#' @param job Batchtools job. (BATCHTOOLS)
#' @param fit_real_out If distribution for the outliers should be a fit from the real
#' outliers (TRUE) or a change from a fit of regular insatnces (FALSE).
#' @param dist_type_out Type of distribution that is used for the outliers. Either 'vine',
#' 'gauss' or 'unif'.
#' @param change_par Amount of change for synthetic outliers. Only implemented for dist_type
#' 'gauss' in which it is the scaling of the variances.
#' @param xi Percentage of outliers in generated data. Numeric in [0,1] or 'NA'.
#' If 'NA' all outliers up to max_reg are used.
#' @param max_reg Maximal number of regular instances. If 'Inf' all are used.
#' @param max_out Maximal number of outliers. If 'Inf' all are used.
#' @param perc_train Percentage of data used for training. If 'NA' there is no 
#' train-test split (unsupervised detcetion).
#' @param fitRegular The fit of regular instances. Only used when fit_real_out = FALSE.
#' @param n_synth_out Alternative to xi which directly determines number of outliers. If 
#' set, xi is ignored.
#' 
#' @return A list with the data having real regulars but synthetic outliers.
synthOutlier <- function(data, job=NULL, # specific to batchtools
                         fit_real_out, dist_type_out, change_par,
                         xi=NA, max_reg=Inf, max_out=Inf, perc_train=NA,
                         dist_type_reg=NULL, fitRegular=NULL, n_synth_out=NULL) {
  
  if(!is.na(perc_train)) {
    if(!is.na(xi)) {
      stop("Not supporting xi with synthetic data and train-test split.")
    }
    tt_list <- real(data=data,
                    xi=NA,
                    max_reg=max_reg,
                    max_out=max_out, 
                    perc_train=perc_train)
    tt_list$train <- synthOutlier(data=tt_list$train$data %>%
                                    as.data.frame() %>%
                                    bind_cols(outlier=tt_list$train$label),
                                  fit_real_out=fit_real_out,
                                  dist_type_out=dist_type_out,
                                  change_par=change_par,
                                  xi=xi)
    return(tt_list)
  }
  
  prep_list <- prepareData(data=data, max_reg=max_reg, max_out=max_out) 
  
  if(fit_real_out) {
    real_outliers <- prep_list$real_outliers %>%
      mutate_all(jitterAttr)
    fitOutlier <- do.call(paste0(dist_type_out, "Fit"), list(dataset=real_outliers))
    fitRegular <- NULL
    dist_type_reg <- NULL
  } else {
    real_regulars <- prep_list$real_regulars %>%
      mutate_all(jitterAttr)
    if(is.null(fitRegular)) {
      fitRegular <- do.call(paste0(dist_type_out, "Fit"), list(dataset=real_regulars))
      dist_type_reg <- dist_type_out
    }
    fitOutlier <- do.call(paste0(dist_type_out, "Change"), list(fit=fitRegular,
                                                                change_par=change_par))
  }
  
  n_reg <- nrow(prep_list$real_regulars)
  n_synth_out <- n_reg
  if(is.null(n_synth_out)) {
    n_synth_out <- ifelse(is.na(xi),
                          nrow(prep_list$real_outliers),
                          ceiling((n_reg*xi)/(1-xi))) 
  }
  clust_inliers <- fitOutlier$classification

  synth_outliers <- do.call(paste0(dist_type_out, "Sample"),
                            list(fit=fitOutlier,
                                 n=n_synth_out))
  clust_outliers <- synth_outliers[, 1]
  synth_outliers <- synth_outliers[, 2:ncol(synth_outliers)]
  colnames(synth_outliers) <- colnames(prep_list$real_regulars)
  
  
  data_to_save <- cbind(as.matrix(rbind(prep_list$real_regulars, synth_outliers)),
                        c(clust_inliers, clust_outliers),
                        c(rep("0", n_reg), rep("1", n_synth_out)))
  
  write.table(data_to_save,
              paste0("gendatasets/synthOutlier", "_nin", n_reg, "_nout", n_synth_out, ".csv"),
              quote=FALSE, sep=",", col.names=F, row.names=F)
			  
  write.table(fitOutlier$parameters,
              paste0("gendatasets/var_synthOutlier", "_nin", n_reg, "_nout", n_synth_out, ".csv"),
              quote=FALSE, sep=",", row.names=F)
  
  return(list(data=as.matrix(rbind(prep_list$real_regulars, synth_outliers)),
              label=c(rep("no", n_reg),
                      rep("yes", n_synth_out)),
              xi=xi,
              dist_type_reg=dist_type_reg,
              fit_real_out=fit_real_out,
              dist_type_out=dist_type_out,
              fitRegular=fitRegular,
              fitOutlier=fitOutlier))
  
} # END fun synthOutlier
# ------------------------------------------------------------------- #



#' Generate a fully synthetic outlier benchmark data set from a real one.
#' 
#' See synthRegular and synthOutlier for parameters.
#' 
#' @return A list with the generated data and fitted distributions.
synth <- function(data, job=NULL, # specific to batchtools
                  dist_type_reg, n_synth_reg, 
                  fit_real_out, dist_type_out, change_par,
                  xi=NA, max_reg=Inf, max_out=Inf, perc_train=NA) {
  
  if(!is.na(perc_train)) {
    if(!is.na(xi)) {
      stop("Not supporting xi with synthetic data and train-test split.")
    }
    tt_list <- real(data=data,
                    xi=NA,
                    max_reg=max_reg,
                    max_out=max_out, 
                    perc_train=perc_train)
    tt_list$train <- synth(data=tt_list$train$data %>%
                             as.data.frame() %>%
                             bind_cols(outlier=tt_list$train$label),
                           job=job,
                           dist_type_reg=dist_type_reg,
                           n_synth_reg=n_synth_reg,
                           fit_real_out=fit_real_out,
                           dist_type_out=dist_type_out,
                           change_par=change_par,
                           xi=xi)
    return(tt_list)
  }
  
  regular_list <- synthRegular(data=data,
                               dist_type_reg=dist_type_reg,
                               n_synth_reg=n_synth_reg,
                               xi=NA,
                               max_reg=max_reg, 
                               max_out=max_out, 
                               perc_train=NA)
  synth_regulars <- regular_list$data[regular_list$label=="no", ]
  
  n_synth_out <- ifelse(is.na(xi),
                        nrow(regular_list$data[regular_list$label=="yes", ]),
                        ceiling((nrow(synth_regulars)*xi)/(1-xi)))
  
  # Needs a different seed to produce different outliers
  set.seed(job$problem$seed + job$repl + 10) # seed of the problem + [replication number] - 1 (job$problem$seed + job$repl - 1)
  if(dist_type_out==dist_type_reg) {
    outlier_list <- synthOutlier(data=data,
                                 fit_real_out=fit_real_out,
                                 dist_type_out=dist_type_out,
                                 change_par=change_par,
                                 xi=NA,
                                 max_reg=max_reg, 
                                 max_out=max_out, 
                                 perc_train=NA,
                                 dist_type_reg=dist_type_reg,
                                 fitRegular=regular_list$fitRegular,
                                 n_synth_out=n_synth_out)
  } else {
    outlier_list <- synthOutlier(data=data,
                                 fit_real_out=fit_real_out,
                                 dist_type_out=dist_type_out,
                                 change_par=change_par,
                                 xi=NA,
                                 max_reg=max_reg, 
                                 max_out=max_out, 
                                 perc_train=NA,
                                 n_synth_out=n_synth_out)
  }
  synth_outliers <- outlier_list$data[outlier_list$label=="yes", ]
  
  data_to_save <- cbind(as.matrix(rbind(synth_regulars, synth_outliers)), 
						c(rep("0", nrow(synth_regulars)), rep("1", nrow(synth_outliers))))
  
  write.table(data_to_save, paste0("gendatasets/", "synth_changepar", change_par,
			"_xi", xi, "_nin", nrow(synth_regulars), "_nout", n_synth_out, "_dist", dist_type_out, ".csv"),
			quote=FALSE, sep=",", col.names=F, row.names=F)
  
  # Return instance
  return(list(data=as.matrix(rbind(synth_regulars, synth_outliers)),
              label=c(rep("no", nrow(synth_regulars)),
                      rep("yes", nrow(synth_outliers))),
              xi=xi,
              dist_type_reg=dist_type_reg,
              fit_real_out=fit_real_out,
              dist_type_out=dist_type_out,
              fitRegular=regular_list$fitRegular,
              fitOutlier=outlier_list$fitOutlier))
  
} # END fun synth
# # ------------------------------------------------------------------- #
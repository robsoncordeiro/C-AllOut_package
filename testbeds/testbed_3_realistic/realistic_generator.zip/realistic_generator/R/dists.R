
# TEMPLATE ----------------------------------------------------------------

# xxxxFit <- function(dataset) {
#   
# } # END fun xxxxFit
#----------------------------------#

# xxxxChange <- function(fit, change_type, change_par) {
#   
# } # END fun xxxxChange
#----------------------------------#

# xxxxSample <- function(fit, n_obs) {
#   
# } # END fun xxxxSample
#----------------------------------#

# xxxxDensity <- function(fit, dataset) {
#   
# } # END fun xxxxDensity
#----------------------------------#


# vine --------------------------------------------------------------------

vineFit <- function(dataset) {
  margins_controls = list(mult = NULL, xmin = NaN, xmax = NaN, bw = NA)
  copula_controls = list(family_set = "all", 
                         structure = NA, par_method = "mle", nonpar_method = "constant", 
                         mult = 1, selcrit = "bic", psi0 = 0.9, presel = TRUE, trunc_lvl = Inf, 
                         tree_crit = "tau", threshold = 0, keep_data = FALSE, show_trace = FALSE, 
                         cores = 1)
  d <- ncol(dataset)
  margins_controls <- rvinecopulib:::expand_margin_controls(margins_controls,
                                                            d,
                                                            dataset)
  vine <- list()
  vine$margins <- lapply(1:d, function(k) my_kde1d(dataset[, k]))
  vine$margins_controls <- margins_controls
  copula_controls$data <- sapply(1:d, function(k) kde1d::pkde1d(dataset[, k],
                                                                vine$margins[[k]]))
  vine$copula <- do.call(rvinecopulib::vinecop, copula_controls)
  vine$copula_controls <- copula_controls
  return(rvinecopulib:::finalize_vine(vine, dataset, keep_data=TRUE))
  ## OLD (without explicit margins)
  # vine_fit <- rvinecopulib::vine(data=dataset,
  #                                copula_controls = list(family_set="nonparametric")) # family_set: ?rvinecopulib::bicop
  # return(vine_fit)
} # END fun vineFit
#----------------------------------#

vineChange <- function(fit, change_type, change_par) {
  fit$copula <- rvinecopulib::vinecop(fit$copula_controls$data, family = "indep")
  return(fit)
} # END fun vineChange
#----------------------------------#

vineSample <- function(fit, n_obs) {
  synth <- rvinecopulib::rvine(vine = fit, n = n_obs)
  return(synth)
} # END fun vineSample
#----------------------------------#

vineDensity <- function(fit, dataset) {
  dens <- rvinecopulib::dvine(vine = fit, x = dataset)
  idx_notfinite <- which(!is.finite(dens)) 
  if(length(idx_notfinite) > 0) { # some are NaN
    dens[idx_notfinite] <- mean(dens[-idx_notfinite])
  }
  return(dens)
} # END fun vineDensity
#----------------------------------#



# gauss -------------------------------------------------------------------

require("mclust")
gaussFit <- function(dataset) {
  return(mclust::densityMclust(data=dataset,
                               modelNames=c("VEI"),
                               verbose=FALSE))
} # END fun gaussFit
#----------------------------------#

gaussChange <- function(fit, change_type, change_par) {
  fit$parameters$variance$scale <- fit$parameters$variance$scale * change_par#^(1/fit$d)
  return(fit)
} # END fun gaussChange
#----------------------------------#

gaussSample <- function(fit, n_obs) {
  synth <- mclust::sim(modelName = fit$modelName, 
                       parameters = fit$parameters, 
                       n = n_obs)
  return(synth)
} # END fun gaussSample
#----------------------------------#

gaussDensity <- function(fit, dataset) {
  return(mclust::predict.densityMclust(object=fit,
                                       newdata=dataset,
                                       what="dens"))
} # END fun gaussDensity
#----------------------------------#



# unif --------------------------------------------------------------------

#' @param bounds_ext Gives percentage of extension of the bounds. E.g. 0.1 for 10 %
unifFit <- function(dataset) {
  bounds <- apply(dataset, 2, range) # 1st row is minimum and 2nd is maximum
  return(bounds)
} # END fun unifFit
#----------------------------------#

unifChange <- function(fit, change_type, change_par) {
  if(is.na(change_par)) {
    change_par <- 0
  }
  if(change_par != 0) {
    increase <- change_par *  (fit[2,] - fit[1,])
    fit[1,] <- fit[1,] - increase
    fit[2,] <- fit[2,] + increase
  } 
  return(fit)
} # END fun unifChange
#----------------------------------#

unifSample <- function(fit, n_obs) {
  synth <- matrix(runif(n=ncol(fit)*n_obs), ncol=ncol(fit))
  synth <- sweep(synth, 2, fit[2,] - fit[1,], FUN = "*")
  synth <- sweep(synth, 2,fit[1,], FUN = "+")
  colnames(synth) <- colnames(fit)
  return(synth)
} # END fun unifSample
#----------------------------------#

unifDensity <- function(fit, dataset) {
  vol <- prod(fit[2,] - fit[1,])
  # Check if in box
  is_in_box <- dataset
  for(cur_d_idx in 1:ncol(fit)) {
    is_in_box[, cur_d_idx] <- (is_in_box[, cur_d_idx] >= fit[1,cur_d_idx]) & (is_in_box[, cur_d_idx] <= fit[2,cur_d_idx])
  }
  is_in_box <- apply(is_in_box, 1, prod)
  return(is_in_box/vol)
} # END fun unifDensity
#----------------------------------#

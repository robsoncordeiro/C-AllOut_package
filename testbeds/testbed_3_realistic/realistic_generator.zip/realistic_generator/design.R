
# Design -------------------------------------------------------------

library("dplyr")
# job_pars <- batchtools::getJobTable() %>% filter(problem=="GaussMixDev")
# removeExperiments(job_pars$job.id)

## PROBLEMS
meta_data <- read.csv("datasets/meta-data.csv")
data_names <- "ALOI" # ALOI, Glass, skin, smtp, Waveform
# n_synth_reg <- c("1000", "real_n", "increase_with_d")
# dist_types <- c("vine", "gauss", "unif")
dist_types <- c("gauss")
n_synth_reg <- c("real_n")
# fit_real_out <- c(TRUE, FALSE) # Seperate tables, since change_par is NA if fit_real_out==TRUE
# change_pars <- list(vine=c(NA),
#                     gauss=c(1, 2, 5, 10),
#                     unif=c(0, 0.1, 0.2))
change_pars <- list(vine=c(NA),
                    gauss=c(5),
                    unif=c(0.1))
# xi <- c(0.01, 0.05, 0.1)
max_reg <- max_out <- 10000
perc_train <- 0.7

## ALGORITHMS
ks <-c(5, 100) 

## GENERAL
n_repls <- 1

expand_grid <- function(...) {
  return(expand.grid(..., stringsAsFactors = FALSE))
}


# DetectOutliers ----------------------------------------------------------

## Problems for "real"
# pdes_real <- list()
# for(cur_data_name_idx in 1:length(data_names)) {
#   table_for_problem <- expand_grid(xi=xi,
#                                    max_reg=max_reg,
#                                    max_out=max_out)
#   pdes_real[[cur_data_name_idx]] <- table_for_problem
# }
# names(pdes_real) <- paste0("Real_", data_names)
# 
# # ------------------------------------------------------ #
# 
# ## Problems for "synthRegular"
# pdes_synthRegular <- list()
# for(cur_data_name_idx in 1:length(data_names)) {
#   table_for_problem <- NULL
#   for(dist_type_reg in dist_types) {
#     table_for_dist_type_reg <- expand_grid(xi=xi,
#                                            max_reg=max_reg,
#                                            max_out=max_out,
#                                            dist_type_reg=dist_type_reg,
#                                            n_synth_reg=n_synth_reg)
#     table_for_problem <- rbind(table_for_problem, 
#                                table_for_dist_type_reg)
#   }
#   pdes_synthRegular[[cur_data_name_idx]] <- table_for_problem
# }
# names(pdes_synthRegular) <- paste0("SynthRegular_", data_names)
# 
# # ------------------------------------------------------ #
# 
## Problems for "synthOutlier"
pdes_synthOutlier <- list()
for(cur_data_name_idx in 1:length(data_names)) {
  table_for_problem <- NULL
  for(dist_type_out in dist_types) {
    table_for_dist_type_out <- expand_grid(fit_real_out=FALSE,
                                           dist_type_out=dist_type_out,
                                           change_par=change_pars[[dist_type_out]])
    table_for_problem <- rbind(table_for_problem,
                               table_for_dist_type_out)
  }
  pdes_synthOutlier[[cur_data_name_idx]] <- table_for_problem
}
names(pdes_synthOutlier) <- paste0("SynthOutlier_", data_names)


# ------------------------------------------------------ #

## Problems for "synth"
# pdes_synth <- list()
# for(cur_data_name_idx in 1:length(data_names)) {
#   table_for_problem <- NULL
#   for(dist_type_out in dist_types) {
#     for(dist_type_reg in dist_types) {
#       # Some comb are not useful
#       if(dist_type_reg=="gauss" & dist_type_out=="vine") {
#         next()
#       }
#       if(dist_type_reg=="vine" & dist_type_out=="gauss") {
#         next()
#       }
#       if(dist_type_reg=="unif" & dist_type_out=="gauss") {
#         next()
#       }
#       if(dist_type_reg=="unif" & dist_type_out=="vine") {
#         next()
#       }
#       # if (dist_type_reg != dist_type_out) {
#       #   next()
#       # }
#       table_for_dist_type <- expand_grid(xi=xi,
#                                          max_reg=max_reg,
#                                          max_out=max_out,
#                                          dist_type_reg=dist_type_reg,
#                                          n_synth_reg=n_synth_reg, 
#                                          fit_real_out=FALSE,
#                                          dist_type_out=dist_type_out,
#                                          change_par=change_pars[[dist_type_out]])
#       # table_for_dist_type_fit_out <- expand_grid(xi=xi,
#       #                                            max_reg=max_reg,
#       #                                            max_out=max_out,
#       #                                            dist_type_reg=dist_type_reg,
#       #                                            n_synth_reg=n_synth_reg, 
#       #                                            fit_real_out=TRUE,
#       #                                            dist_type_out=dist_type_out,
#       #                                            change_par=NA)
#       table_for_problem <- rbind(table_for_problem, 
#                                  table_for_dist_type) 
#     }
#   }
#   pdes_synth[[cur_data_name_idx]] <- table_for_problem
# }
# names(pdes_synth) <- paste0("Synth_", data_names)

# ------------------------------------------------------ #

# Stich it together
pdes <- c(pdes_synthOutlier)

# For algorihm
ades = list(
  DetectOutliers = rbind(expand.grid(method_name=c("kde", "iso"),
                                     method_par=NA,
                                     stringsAsFactors=FALSE),
                         expand.grid(method_name=c("wknn", "lof"),
                                     method_par=ks,
                                     stringsAsFactors=FALSE)
  )
)

addExperiments(pdes, ades, repls = n_repls)

# 
# 
# # ClassifyOutliers --------------------------------------------------------
# 
# # Take problems from DetectOutliers
# pdes_synthRegular <- lapply(pdes_synthRegular, function(tab) tab %>% 
#                  mutate(xi=NA, 
#                         n_synth_reg=ifelse(!is.na(n_synth_reg), "real_n", n_synth_reg)) %>%
#                  distinct() %>%
#                  mutate(perc_train=perc_train))
# pdes_others <- lapply(c(pdes_real, pdes_synthOutlier), function(tab) tab %>% 
#                  mutate(xi=NA) %>%
#                  distinct() %>%
#                  mutate(perc_train=perc_train))
# 
# ades = list(
#   ClassifyOutliers = data.frame()
# )
# 
# addExperiments(c(pdes_synthRegular, pdes_others), ades, repls = n_repls)

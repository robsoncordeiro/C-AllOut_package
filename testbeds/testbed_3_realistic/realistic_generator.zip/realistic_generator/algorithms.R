
source("check-packages.R")
source("helper.R")

# Parameter: method_name, method_par
detectOutliers <- function(data, job, instance, 
                           method_name, method_par, 
                           ...) {
  if(!is.null(instance$train)) {
    stop("It seems there has been a train-test split.")
  }
  
  # Sometimes data has constant attributes (all values equal) due to the sampling
  idx_const <- which(apply(instance$data, 2, sd) == 0)
  if(length(idx_const) > 0) {
    instance$data <- instance$data[,-idx_const]
  }
  
  dect_res <- do.call(method_name, list(dataset=instance$data,
                                        method_par=method_par))
  
  n_out <- nrow(instance$data) - instance$fitRegular$n
  dens_reg <- NULL
  dens_out <- NULL
  if(!is.null(instance$dist_type_reg)) {
    dens_reg <- do.call(paste0(instance$dist_type_reg, "Density"), list(fit=instance$fitRegular,
                                                                        dataset=instance$data))
    write.table(dens_reg,
                paste0("gendatasets/", "predictInlierDens_synthOutlier",
                       "_nin", instance$fitRegular$n, "_nout", n_out, ".csv"),
                quote=FALSE, sep=",", row.names=F)
    if(!is.null(instance$dist_type_out)) {
      dens_out <- do.call(paste0(instance$dist_type_out, "Density"), list(fit=instance$fitOutlier,
                                                                          dataset=instance$data))
    }
  }
  
  xi <- ifelse(is.na(instance$xi),
               sum(instance$label=="yes")/length(instance$label),
               instance$xi)
  
  result_list <- list(process_label=instance$label,
                      method_pred=dect_res$unsup_scores,
                      method_fit=dect_res$method_fit,
                      method_name=method_name,
                      dens_reg=dens_reg,
                      dens_out=dens_out,
                      xi=xi,
                      real_xi=sum(instance$label=="yes")/length(instance$label),
                      fitRegular=instance$fitRegular,
                      fitOutlier=instance$fitOutlier)
  
  # return(result_list)
  return(c(getQual(result_list),
           list(fitRegular=reduceFitList(instance$fitRegular,
                                         dist_type=instance$dist_type_reg),
                fitOutlier=reduceFitList(instance$fitOutlier,
                                         dist_type=instance$dist_type_out),
                real_xi=sum(instance$label=="yes")/length(instance$label))))
  
}
addAlgorithm(name = "DetectOutliers", fun = detectOutliers)


# ================================================================= #


# Parameter: None
classifyOutliers <- function(data, job, instance, 
                             ...) {
  
  if(is.null(instance$train)) {
    stop("It seems there has been no train-test split.")
  }
  
  train_data <- instance$train$data %>%
    as.data.frame() %>%
    mutate(class=factor(instance$train$label)) 
  test_data <- instance$test$data %>%
    as.data.frame()
  
  ctrl <- caret::trainControl(method = "repeatedcv",
                              number = 10,
                              repeats = 10)
  class_fit <- caret::train(class ~ ., data = train_data,
                            method = "ranger",
                            metric = "Kappa",
                            trControl = ctrl)
  pred <- caret::predict.train(object = class_fit,
                               newdata = test_data,
                               type = "raw")
  
  result_list <- list(process_label=instance$test$label,
                      method_pred=pred,
                      method_fit=class_fit,
                      method_name="ranger",
                      xi=instance$xi,
                      fitRegular=instance$fitRegular,
                      fitOutlier=instance$fitOutlier)
  
  # return(result_list)
  return(c(getClassQual(result_list),
           list(fitClass=reduceFitList(class_fit,
                                       dist_type="ranger"))))
  
}
addAlgorithm(name = "ClassifyOutliers", fun = classifyOutliers)

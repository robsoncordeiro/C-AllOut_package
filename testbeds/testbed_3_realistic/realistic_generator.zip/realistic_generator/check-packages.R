
cran <- c("batchtools",
          "data.table",
          "foreign",
          "pROC",
          "PRROC",
          "mclust",
          "FNN",
          "dbscan",
          "e1071",
          "scales",
          "dplyr",
          "tidyr",
          "stringr",
          "rvinecopulib",
          "np",
          "caret",
          "ranger",
          "isofor",
          "ggplot2")
github <- c()
source_file <- c()

missing_pkg <- FALSE
for(pkg in cran) {
  if(!(pkg %in% installed.packages())) {
    install.packages(pkg)
  }
  library(pkg, character.only = TRUE)
}
for(pkg in github) {
  stop("Packages from github not implemented yet")
}
for(pkg in source_file) {
  if(!(pkg %in% installed.packages())) {
    message("Please install package ",  pkg," first!")
    missing_pkg <- TRUE
  }
  library(pkg, character.only = TRUE)
}
if(missing_pkg) {
  stop("Cannot proceed. package(s) missing")
} 
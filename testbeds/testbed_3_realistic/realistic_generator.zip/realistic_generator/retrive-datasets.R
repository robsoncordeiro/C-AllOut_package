
# Tested with R 3.6.1 on Manjaro Linux

# The 'Litrature" data sets were taken from UCI or their original source (except KDDCup99 and ALOI).
# The "Semantic" ones and KDDCup99 directly from DAMI: https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/

folder <- "dataset_download/"
dir.create(folder)

if(!("R.utils" %in% installed.packages())) {
  install.packages("R.utils")
}
library("R.utils")
library("dplyr")
source('R/write-to-arff.R')

# DAMI --------------------------------------------------------------------

untarToFolder <- function(file, tar="semantic") {
  untar(tarfile = paste0(folder, tar, ".tar.gz"), 
        files = paste0(tar, "/", file), 
        exdir = folder) # Untar file
  file.copy(from = paste0(folder, tar, "/", file),
            to = folder) # Copy to correct folder
}


## LITERATURE
download.file(url = "https://www.dbs.ifi.lmu.de/research/outlier-evaluation/input/literature.tar.gz", 
              destfile = paste0(folder, "literature.tar.gz"))
untarToFolder(file="ALOI/ALOI.arff", tar="literature")
untarToFolder(file="KDDCup99/KDDCup99_original.arff", tar="literature")
unlink(paste0(folder, "literature/"), recursive = TRUE) # remove folder
unlink(paste0(folder, "literature.tar.gz")) # remove tar

## SEMANTIC
download.file(url = "https://www.dbs.ifi.lmu.de/research/outlier-evaluation/input/semantic.tar.gz", 
              destfile = paste0(folder, "semantic.tar.gz"))

untarToFolder(file="Annthyroid/Annthyroid_07.arff")
untarToFolder(file="Cardiotocography/Cardiotocography_22.arff")
untarToFolder(file="HeartDisease/HeartDisease_withoutdupl_44.arff")
untarToFolder(file="Hepatitis/Hepatitis_withoutdupl_16.arff")
untarToFolder(file="PageBlocks/PageBlocks_10.arff")
untarToFolder(file="Parkinson/Parkinson_withoutdupl_75.arff")
untarToFolder(file="Pima/Pima_withoutdupl_35.arff")
untarToFolder(file="Stamps/Stamps_withoutdupl_09.arff")
untarToFolder(file="Wilt/Wilt_05.arff")

unlink(paste0(folder, "semantic/"), recursive = TRUE) # remove folder
unlink(paste0(folder, "semantic.tar.gz")) # remove tar


# Glass -------------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/glass/glass.data", 
              destfile = paste0(folder, "glass.data"))
dataset <- read.table(paste0(folder, "glass.data"), sep = ",")

### FROM 'glass.names'
# Attribute Information:
# 1. Id number: 1 to 214
# 2. RI: refractive index
# 3. Na: Sodium (unit measurement: weight percent in corresponding oxide, as are attributes 4-10)
# 4. Mg: Magnesium
# 5. Al: Aluminum
# 6. Si: Silicon
# 7. K: Potassium
# 8. Ca: Calcium
# 9. Ba: Barium
# 10. Fe: Iron
# 11. Type of glass: (class attribute)
# -- 1 building_windows_float_processed
# -- 2 building_windows_non_float_processed
# -- 3 vehicle_windows_float_processed
# -- 4 vehicle_windows_non_float_processed (none in this database)
# -- 5 containers
# -- 6 tableware
# -- 7 headlamps

names(dataset) <- c("id", "RI", "Na", "Mg", "Al", "Si", "K", "Ca", "Ba", "Fe", "class")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/Glass/
# A forensic dataset describing types of glass. This version is based on a publication by Keller et al. (HiCS, [1]). The authors use the class 6 (minority) as outlier and all other classes as inliers. [...]
# table(dataset$class)

dataset %>%
  mutate(outlier = factor(ifelse(class == 6, yes = 'yes', no = 'no'))) %>%
  select("RI", "Na", "Mg", "Al", "Si", "K", "Ca", "Ba", "Fe", "id", "outlier")  %>%
  writeToArff(file=paste0(folder, "Glass.arff"), relation = "Glass")  

unlink(paste0(folder, "glass.data"))



# Ionosphere --------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/ionosphere/ionosphere.data", 
              destfile = paste0(folder, "ionosphere.data"))
dataset <- read.table(paste0(folder, "ionosphere.data"), sep = ",")

names(dataset) <- c(paste0("var_", sprintf("%04d", 0:(ncol(dataset) - 2))), "class")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/Ionosphere/
# [...] In this version (HiCS, [1]), the authors use the class b (minority) as outliers and class g as inliers. [...]
# table(dataset$class)

dataset %>%
  mutate(id = row_number(),
         outlier = factor(ifelse(class == 'b', yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "Ionosphere.arff"), relation = "Ionosphere")

unlink(paste0(folder, "ionosphere.data"))



# PenDigits ---------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/pendigits/pendigits.tra", 
              destfile = paste0(folder, "pendigits.tra"))
download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/pendigits/pendigits.tes", 
              destfile = paste0(folder, "pendigits.tes"))

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/PenDigits/
# [...] (merge train and test [pendigits.tes and pendigits.tra]).
train <- read.table(paste0(folder, "pendigits.tra"), sep = ",")
test <- read.table(paste0(folder, "pendigits.tes"), sep = ",")
dataset <- rbind(train, test)

names(dataset) <- c(paste0("var_", sprintf("%04d", 0:(ncol(dataset) - 2))), "class")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/PenDigits/
# [...] Class 4, defined here as outlier [...]
# table(dataset$class)

dataset %>%
  mutate(id = row_number(),
         outlier = factor(ifelse(class == 4, yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "PenDigits.arff"), relation = "PenDigits")

rm(train, test)
unlink(paste0(folder, "pendigits.tra"))
unlink(paste0(folder, "pendigits.tes"))



# Shuttle -----------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/shuttle/shuttle.trn.Z", 
              destfile = paste0(folder, "shuttle.trn.Z"))
if(.Platform$OS.type == "unix") {
  system(command = paste0("gzip -d < ", folder, "shuttle.trn.Z  > ", folder, "shuttle.trn"))
  unlink(paste0(folder, "shuttle.trn.Z"))
} else {
  stop("You either need a unix machine, or manually unzip shuttle.trn.Z and continue from here.")
}
download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/statlog/shuttle/shuttle.tst", 
              destfile = paste0(folder, "shuttle.tst"))

### CAUTION different from https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/Shuttle/
# [...] (shuttle.tst, [1] only uses test set) 
## We use both, train and test.
train <- read.table(paste0(folder, "shuttle.trn"))
test <- read.table(paste0(folder, "shuttle.tst"))
dataset <- rbind(train, test)

names(dataset) <- c(paste0("var_", sprintf("%04d", 0:(ncol(dataset) - 2))), "class")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/Shuttle/
# [...] using classes 1, 3, 4, 5, 6 and 7 as inliers and class 2 as outlier [...]
table(dataset$class)

dataset %>%
  mutate(id = row_number(),
         outlier = factor(ifelse(class == 2, yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "Shuttle.arff"), relation = "Shuttle")

rm(train, test)
unlink(paste0(folder, "shuttle.trn"))
unlink(paste0(folder, "shuttle.tst"))



# Waveform ----------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/waveform/waveform.data.Z", 
              destfile = paste0(folder, "waveform.data.Z"))
if(.Platform$OS.type == "unix") {
  system(command = paste0("gzip -d < ", folder, "waveform.data.Z  > ", folder, "waveform.data"))
  unlink(paste0(folder, "waveform.data.Z"))
} else {
  stop("You either need a unix machine, or manually unzip waveform.data.Z and continue from here.")
}
dataset <- read.table(paste0(folder, "waveform.data"), sep = ",")

names(dataset) <- c(paste0("var_", sprintf("%04d", 0:(ncol(dataset) - 2))), "class")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/Waveform/
# [...] Class 0 was defined here as an outlier class [...]
table(dataset$class)

dataset %>%
  mutate(id = row_number(),
         outlier = factor(ifelse(class == 0, yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "Waveform.arff"), relation = "Waveform")

unlink(paste0(folder, "waveform.data"))



# WBC ---------------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/breast-cancer-wisconsin.data", 
              destfile = paste0(folder, "breast-cancer-wisconsin.data"))
dataset <- read.table(paste0(folder, "breast-cancer-wisconsin.data"), sep = ",")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/WBC/
# [...] we removed 16 instances with missing values, two of them being outliers and 14 inliers. [...]
### FROM 'breast-cancer-wisconsin.names'
# There are 16 instances [...] that contain a single missing [...] value, now denoted by "?". 
bol_NA <- apply(dataset, 1, function(x) any(x == "?"))
sum(bol_NA)
dataset <- dataset[!bol_NA, ]
dataset$V7 <- as.integer(dataset$V7)

### FROM 'breast-cancer-wisconsin.names'
#  Attribute                     Domain
# -- -----------------------------------------
# 1. Sample code number            id number
# 2. Clump Thickness               1 - 10
# 3. Uniformity of Cell Size       1 - 10
# 4. Uniformity of Cell Shape      1 - 10
# 5. Marginal Adhesion             1 - 10
# 6. Single Epithelial Cell Size   1 - 10
# 7. Bare Nuclei                   1 - 10
# 8. Bland Chromatin               1 - 10
# 9. Normal Nucleoli               1 - 10
# 10. Mitoses                      1 - 10
# 11. Class:                       (2 for benign, 4 for malignant)

names(dataset) <- c("id", "Clump_Thickness", "Uniformity_of_Cell_Size", "Uniformity_of_Cell_Shape",
                    "Marginal_Adhesion", "Single_Epithelial_Cell_Size", "Bare_Nuclei", "Bland_Chromatin",
                    "Normal_Nucleoli", "Mitoses ", "class")

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/WBC/
# [...] Examples of benign cancer are considered inliers, examples of malignant cancer are considered outliers. [...]
### FROM 'breast-cancer-wisconsin.names'
# [...] (2 for benign, 4 for malignant)
table(dataset$class)

dataset %>%
  mutate(outlier = factor(ifelse(class == 4, yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "WBC.arff"), relation = "WBC")

unlink(paste0(folder, "breast-cancer-wisconsin.data"))



# WDBC --------------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/wdbc.data", 
              destfile = paste0(folder, "wdbc.data"))
dataset <- read.table(paste0(folder, "wdbc.data"), sep = ",")

names(dataset) <- c("id","class", paste0("var_", sprintf("%04d", 0:(ncol(dataset) - 3))))

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/WDBC/
# [...] we consider examples of benign cancer as inliers and malignant cancer as outliers. [...]
### FROM 'wdbc.names'
# [...] (M = malignant, B = benign)
table(dataset$class)

dataset %>%
  mutate(outlier = factor(ifelse(class == "M", yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "WDBC.arff"), relation = "WDBC")

unlink(paste0(folder, "wdbc.data"))



# WPBC --------------------------------------------------------------------

download.file(url = "https://archive.ics.uci.edu/ml/machine-learning-databases/breast-cancer-wisconsin/wpbc.data", 
              destfile = paste0(folder, "wpbc.data"))
dataset <- read.table(paste0(folder, "wpbc.data"), sep = ",")

### DIFFERENT FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/WPBC/
### FROM 'wpbc.names'
# [...] Lymph node status is missing in 4 cases.
bol_NA <- apply(dataset, 1, function(x) any(x == "?"))
sum(bol_NA)
dataset <- dataset[!bol_NA, ]
dataset$V35 <- as.integer(dataset$V35)

names(dataset) <- c("id","class", paste0("var_", sprintf("%04d", 0:(ncol(dataset) - 3))))

### FROM https://www.dbs.ifi.lmu.de/research/outlier-evaluation/DAMI/literature/WPBC/
# the authors use the class R (minority) as outlier and class N as inlier
table(dataset$class)

dataset %>%
  mutate(outlier = factor(ifelse(class == "R", yes = 'yes', no = 'no'))) %>%
  select(-class)  %>%
  writeToArff(file=paste0(folder, "WPBC.arff"), relation = "WPBC")

unlink(paste0(folder, "wpbc.data"))


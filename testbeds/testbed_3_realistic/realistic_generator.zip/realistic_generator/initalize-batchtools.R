
#### !!!! ONLY EXECUTE ONCE !!!! ####

source("check-packages.R")

reg = makeExperimentRegistry(file.dir = "registry", seed = 7812345)

source("problems.R")
source("algorithms.R")

saveRegistry()
